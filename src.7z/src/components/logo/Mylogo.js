import React from 'react'
import "./logo.css"
import eurisko from "../../assets/images/EURISKO-MOBILITY.png"
function    Mylogo() {
    return (
        <div style={{marginTop:"0px"}}> 
            <img src={eurisko} alt="myLogo" className="davduveye"/>
        </div>
    )
}

export default Mylogo
